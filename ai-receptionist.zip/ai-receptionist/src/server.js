const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config');
const voiceRoutes = require('./routes/voice');
const smsRoutes = require('./routes/sms');

const app = express();
app.use(bodyParser.urlencoded({ extended: false })); // Twilio webhooks send form-encoded bodies
app.use(bodyParser.json());

app.use('/voice', voiceRoutes);
app.use('/sms', smsRoutes);

app.get('/health', (req, res) => res.json({ ok: true, business: config.business.name }));

app.listen(config.port, () => {
  console.log(`AI receptionist running on port ${config.port}`);
  console.log(`Point Twilio's voice webhook at ${config.publicBaseUrl}/voice/incoming`);
  console.log(`Point Twilio's SMS webhook at ${config.publicBaseUrl}/sms/incoming`);
});
