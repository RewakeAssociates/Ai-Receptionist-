const express = require('express');
const twilio = require('twilio');
const config = require('../config');
const leads = require('../lib/leads');
const ai = require('../lib/ai');

const router = express.Router();
const client = twilio(config.twilio.accountSid, config.twilio.authToken);

const OPT_OUT_WORDS = ['stop', 'unsubscribe', 'cancel', 'end', 'quit'];
const CALLBACK_WORDS = ['call', 'callback', 'call me', 'call back', 'phone me'];

router.post('/incoming', async (req, res) => {
  const from = req.body.From;
  const body = (req.body.Body || '').trim();

  // Honor opt-outs immediately, no AI call needed. (Twilio/carriers also
  // enforce STOP at the network level, but we mirror it in lead status.)
  if (OPT_OUT_WORDS.includes(body.toLowerCase())) {
    leads.upsertLead(from, { status: 'stopped' });
    res.type('text/xml').send('<Response></Response>');
    return;
  }

  // Fast path: a bare "CALL"/"CALLBACK" reply skips the AI round-trip entirely —
  // instant confirmation, and staff gets notified right away. Anything more
  // detailed than these exact words (e.g. "can you call me about my quote")
  // still goes through the AI below, since request_callback there captures
  // the reason and preferred time too.
  if (CALLBACK_WORDS.includes(body.toLowerCase())) {
    leads.appendMessage(from, 'user', body);
    leads.upsertLead(from, { status: 'callback_requested' });

    const confirmText = `Got it — we'll call you back shortly. Talk soon!`;
    leads.appendMessage(from, 'assistant', confirmText);
    await client.messages.create({ to: from, from: config.twilio.phoneNumber, body: confirmText });

    if (config.business.handoffPhone) {
      await client.messages.create({
        to: config.business.handoffPhone,
        from: config.twilio.phoneNumber,
        body: `Callback requested: ${from} (replied "${body}") — call them back when you can.`,
      });
    }

    res.type('text/xml').send('<Response></Response>');
    return;
  }

  leads.appendMessage(from, 'user', body);
  const lead = leads.upsertLead(from, { status: 'in_conversation' });

  const history = lead.conversation.map((m) => ({ role: m.role, text: m.text }));

  try {
    const { reply, sideEffects } = await ai.converse(history);

    if (reply) {
      leads.appendMessage(from, 'assistant', reply);
      await client.messages.create({ to: from, from: config.twilio.phoneNumber, body: reply });
    }

    for (const effect of sideEffects) {
      if (effect.type === 'booked') {
        leads.upsertLead(from, { status: 'booked' });
        if (config.business.handoffPhone) {
          await client.messages.create({
            to: config.business.handoffPhone,
            from: config.twilio.phoneNumber,
            body: `New booking via AI receptionist: ${from} — ${JSON.stringify(effect.booking)}`,
          });
        }
      } else if (effect.type === 'handoff') {
        leads.upsertLead(from, { status: 'needs_human' });
        if (config.business.handoffPhone) {
          await client.messages.create({
            to: config.business.handoffPhone,
            from: config.twilio.phoneNumber,
            body: `Needs a human: ${from} — reason: ${effect.reason}`,
          });
        }
      } else if (effect.type === 'callback_requested') {
        leads.upsertLead(from, { status: 'callback_requested' });
        if (config.business.handoffPhone) {
          await client.messages.create({
            to: config.business.handoffPhone,
            from: config.twilio.phoneNumber,
            body: `Callback requested: ${from} — wants a call ${effect.preferredTime}. Reason: ${effect.reason}`,
          });
        }
      }
    }
  } catch (err) {
    console.error('AI conversation error:', err.message);
  }

  res.type('text/xml').send('<Response></Response>');
});

module.exports = router;
