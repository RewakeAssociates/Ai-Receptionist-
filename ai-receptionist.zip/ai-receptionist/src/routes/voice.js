const express = require('express');
const twilio = require('twilio');
const config = require('../config');
const leads = require('../lib/leads');

const router = express.Router();
const VoiceResponse = twilio.twiml.VoiceResponse;
const client = twilio(config.twilio.accountSid, config.twilio.authToken);

// Twilio hits this when a call comes in to your business number.
router.post('/incoming', (req, res) => {
  const twiml = new VoiceResponse();

  // Offer an immediate callback option before the caller commits to waiting.
  // If they press 1, /voice/callback-request handles it and the call ends there.
  // If they don't press anything, TwiML falls through to the normal dial below.
  const gather = twiml.gather({
    numDigits: 1,
    timeout: 6,
    action: '/voice/callback-request',
    method: 'POST',
  });
  gather.say(
    `Thanks for calling ${config.business.name}. Press 1 anytime to request a callback instead of waiting. Otherwise, please hold.`
  );

  if (config.business.staffPhoneToRing) {
    const dial = twiml.dial({
      timeout: config.business.ringTimeoutSeconds,
      action: '/voice/after-dial', // Twilio calls this once the dial attempt ends
    });
    dial.number(config.business.staffPhoneToRing);
  } else {
    // No staff number configured — go straight to "we'll text you" (skip the ring).
    twiml.say('We are unavailable right now, please check your texts.');
    twiml.hangup();
  }

  res.type('text/xml').send(twiml.toString());
});

// Caller pressed a digit during the initial greeting.
router.post('/callback-request', async (req, res) => {
  const digit = req.body.Digits;
  const callerNumber = req.body.From;
  const twiml = new VoiceResponse();

  if (digit === '1') {
    leads.upsertLead(callerNumber, { status: 'callback_requested', source: 'voice_ivr' });

    twiml.say("Got it — we'll call you back shortly. Thanks!");
    twiml.hangup();

    try {
      if (config.business.handoffPhone) {
        await client.messages.create({
          to: config.business.handoffPhone,
          from: config.twilio.phoneNumber,
          body: `Callback requested via phone menu: ${callerNumber} — call them back when you can.`,
        });
      }
      await client.messages.create({
        to: callerNumber,
        from: config.twilio.phoneNumber,
        body: `Thanks for calling ${config.business.name} — we've got your callback request and will reach out shortly.`,
      });
    } catch (err) {
      console.error('Failed to notify/confirm callback request:', err.message);
    }
  } else {
    // Anything other than 1 (or no input reaching here at all) — shouldn't
    // normally happen since <Gather> falls through on timeout, but handle
    // stray input defensively.
    twiml.redirect('/voice/incoming');
  }

  res.type('text/xml').send(twiml.toString());
});

// Twilio hits this after the dial attempt (answered, no-answer, busy, failed).
router.post('/after-dial', async (req, res) => {
  const dialStatus = req.body.DialCallStatus; // 'completed' | 'no-answer' | 'busy' | 'failed'
  const callerNumber = req.body.From;
  const twiml = new VoiceResponse();

  if (dialStatus !== 'completed') {
    // Missed call -> mark the lead and fire the recovery SMS.
    leads.upsertLead(callerNumber, { status: 'new', source: 'missed_call' });

    try {
      await client.messages.create({
        to: callerNumber,
        from: config.twilio.phoneNumber,
        body: `Sorry we missed you! This is ${config.business.name}. What can we help with? Reply here, or text CALL if you'd rather we just call you back.`,
      });
      leads.appendMessage(
        callerNumber,
        'assistant',
        `Sorry we missed you! This is ${config.business.name}. What can we help with? Reply here, or text CALL if you'd rather we just call you back.`
      );
    } catch (err) {
      console.error('Failed to send missed-call SMS:', err.message);
    }

    twiml.hangup();
  } else {
    twiml.hangup();
  }

  res.type('text/xml').send(twiml.toString());
});

module.exports = router;
