require('dotenv').config();

module.exports = {
  port: process.env.PORT || 3000,
  publicBaseUrl: process.env.PUBLIC_BASE_URL || `http://localhost:${process.env.PORT || 3000}`,

  twilio: {
    accountSid: process.env.TWILIO_ACCOUNT_SID,
    authToken: process.env.TWILIO_AUTH_TOKEN,
    phoneNumber: process.env.TWILIO_PHONE_NUMBER,
  },

  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY,
    model: 'claude-sonnet-4-6',
  },

  business: {
    name: process.env.BUSINESS_NAME || 'Your Business',
    services: process.env.BUSINESS_SERVICES || 'general services',
    persona: process.env.AI_PERSONA ||
      'Friendly and efficient. Never invent a price. Always confirm the customer\'s name, need, and preferred time before booking.',
    handoffPhone: process.env.HANDOFF_PHONE,
    staffPhoneToRing: process.env.STAFF_PHONE_TO_RING,
    ringTimeoutSeconds: parseInt(process.env.RING_TIMEOUT_SECONDS || '20', 10),
  },

  calcom: {
    apiKey: process.env.CALCOM_API_KEY,
    eventTypeId: process.env.CALCOM_EVENT_TYPE_ID,
  },

  followupDays: parseInt(process.env.FOLLOWUP_DAYS || '30', 10),
};
