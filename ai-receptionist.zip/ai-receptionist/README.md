# AI Receptionist — starter kit

A configurable AI receptionist that:

1. **Missed-call recovery**: incoming call → if unanswered, auto-texts the caller → AI carries the SMS conversation → qualifies the lead → books the appointment (or hands off to a human) → notifies the business owner.
2. **Old-lead revival**: pulls stale leads → sends a scheduled re-engagement text → AI classifies the reply (interested / not now / stop) → routes interested replies into the same booking conversation.
3. **Callback option, three ways in**: a caller can press 1 during the ring to request a callback instead of waiting; a texter can reply `CALL` for an instant confirmation with no AI round-trip; or the AI itself can offer a callback mid-conversation via the `request_callback` tool when texting clearly isn't working for the customer. All three notify the business owner and mark the lead as `callback_requested`.

It is built to be **vertical-agnostic** — one config file (`src/config.js`, generated from `.env`) controls the business name, services, booking rules, and AI persona, so the same codebase works for a plumber, a dentist, a salon, or a real estate agent.

## Stack (and why)

| Piece | Recommendation | Why |
|---|---|---|
| Phone + SMS | **Twilio** (Programmable Voice + Messaging) | Industry standard, per-minute/per-message pricing, no monthly minimum, huge docs/community. A local number costs ~$1.15/mo; calls ~$0.013/min; SMS ~$0.0079/msg (US, subject to change — check Twilio's pricing page). |
| AI conversation | **Claude API** (`claude-sonnet-4-6` in this starter) | Handles the SMS conversation, extracts structured data (name, issue, preferred time) via tool calling. |
| Booking / calendar | **Cal.com API** or **Google Calendar API** (either works — this starter ships a Cal.com adapter and a stub interface so you can swap in Google Calendar, Acuity, ServiceTitan, etc.) | Avoids you having to build your own scheduling UI. |
| Hosting | **Railway** or **Render** (free/cheap tier, one-click deploy from GitHub, gives you a public HTTPS URL Twilio needs for webhooks) | Simplest path to a public webhook endpoint. |
| Lead storage | JSON file in this starter; swap for **Postgres/Supabase** once you have real volume | Keeps the starter runnable with zero external DB setup. |

Nothing here locks you in — every integration point is an isolated file under `src/lib/` so you can swap vendors without touching the conversation logic.

## What's actually in this folder

```
ai-receptionist/
  src/
    server.js            Express app entrypoint, mounts routes
    routes/
      voice.js            Twilio voice webhook: greets, dials staff, detects a miss, fires the SMS
      sms.js               Twilio SMS webhook: runs the AI conversation turn-by-turn
    lib/
      ai.js                Claude API call + conversation state machine + tool-calling for booking
      leads.js             Read/write the lead store (JSON file — swap for a real DB later)
      calendar.js          Booking adapter (Cal.com stub) — swap for Google Calendar/Acuity/etc.
      followup.js          Script you run on a schedule (cron) to re-engage old leads
    config.js              Loads .env into one config object; this is the "per-business" file
    db/leads.json          Local lead store (created automatically)
  .env.example             Every environment variable you need to fill in
  package.json
```

## Setup (step by step)

### 1. Accounts you need
- A Twilio account + a purchased phone number with Voice + SMS enabled.
- An Anthropic API key (console.anthropic.com) for the AI conversation.
- A Cal.com account (free tier is fine) **or** swap `src/lib/calendar.js` for Google Calendar if you prefer — see comments in that file.
- A Railway or Render account to host this (or run locally with `ngrok` for testing).

### 2. Install
```bash
cd ai-receptionist
npm install
cp .env.example .env
# fill in .env with your keys
```

### 3. Run locally for testing
```bash
npm run dev
# in a second terminal, expose it publicly for Twilio's webhooks:
npx ngrok http 3000
```
Copy the `https://xxxx.ngrok.io` URL into your Twilio number's config:
- Voice webhook → `https://xxxx.ngrok.io/voice/incoming`
- Voice status callback → `https://xxxx.ngrok.io/voice/status`
- SMS webhook → `https://xxxx.ngrok.io/sms/incoming`

### 4. Deploy for real
Push this folder to a GitHub repo, connect it to Railway/Render, set the same environment variables there, and point your Twilio webhooks at the deployed URL instead of ngrok.

### 5. Set up old-lead follow-up
`src/lib/followup.js` is a script, not a server route. Run it on a schedule:
- Cheapest: Railway/Render "cron job" add-on, or GitHub Actions scheduled workflow, running `node src/lib/followup.js` once a day.
- It reads `src/db/leads.json`, finds leads whose `lastContact` is older than `FOLLOWUP_DAYS` (see `.env`) and status is `cold`, and sends them a re-engagement SMS. Replies come back through the same `/sms/incoming` webhook and get classified by the AI.

### 6. Customize per business
Edit `.env`:
- `BUSINESS_NAME`, `BUSINESS_SERVICES`, `BOOKING_WINDOW_HOURS` etc.
- `AI_PERSONA` — a short paragraph telling the AI how to talk (tone, what it can promise, what needs a human).
- `HANDOFF_PHONE` — where "urgent" or "needs a human" conversations get flagged.

Everything downstream (the prompt sent to Claude, the SMS copy) is built from these values in `src/config.js` — you shouldn't need to touch the route/logic files to launch a new business.

## Realistic costs (rough, US pricing, check current rates)
- Twilio number: ~$1–2/mo
- Twilio voice + SMS usage: a few cents per interaction — a business doing 200 missed calls/mo is looking at roughly $10–20/mo in Twilio usage
- Claude API: a few cents per conversation depending on length
- Hosting: free–$10/mo on Railway/Render starter tiers
- Total for a small business: commonly **$30–75/mo** all-in, versus a human receptionist or a $300+/mo answering service.

## What this starter does NOT do (be honest with yourself before selling this)
- It doesn't replace a human for complex negotiations, complaints, or anything requiring judgment — it should always have a clear "hand off to a human" escape hatch (this starter texts `HANDOFF_PHONE` when the AI isn't confident).
- It doesn't do outbound cold calling — only inbound calls and outbound SMS to people who already have a relationship with the business (this matters for TCPA/consent compliance — see below).
- Compliance: for SMS, get proper consent language on intake forms and honor STOP replies (this starter auto-handles STOP/unsubscribe keywords, which Twilio also enforces at the carrier level).
