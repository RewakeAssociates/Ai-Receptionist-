# AI receptionist — blueprint

## The two workflows

**1. Missed-call recovery**
Incoming call → rings staff for N seconds → if unanswered, system auto-texts the caller within seconds → AI carries the SMS conversation (qualifies the need, urgency, timing) → books the appointment on the calendar or flags a human handoff → owner gets a notification with the transcript.

**2. Old-lead revival**
Stale/cold leads sit in storage → a daily scheduled job texts a re-engagement message → AI classifies the reply (interested / not now / stop) → interested replies drop into the exact same booking conversation as workflow 1 → owner gets notified when it converts.

Both workflows converge on the same AI conversation engine and the same calendar — that's the point: you build the conversation logic once and it recovers revenue from two different leaks (calls you miss today, and leads you already paid to acquire but never closed).

## Why this order of tech decisions matters

1. **Phone/SMS layer first** (Twilio) — this is the one piece that's hard to swap later, since it's tied to your actual phone number and carrier registration. Get this right before building anything else.
2. **Conversation engine second** (Claude API) — this is where "AI receptionist" actually lives. Tool-calling matters here: you don't want the model *describing* an appointment, you want it *calling a function* that hits your real calendar. Keep the model boxed in with hard rules (never invent prices, always confirm details, hand off anything ambiguous).
3. **Calendar/booking third** — pick whatever the business already uses if possible (Google Calendar, Acuity, ServiceTitan, Calendly). Cal.com is the default here because it has a clean API, but this is the most replaceable piece.
4. **Lead storage fourth** — start dumb (a JSON file, a spreadsheet, Airtable). Don't build a real database until you have real volume; the schema will change once you see actual usage.

## Compliance, non-negotiable

- **A2P 10DLC registration**: US carriers require businesses to register their use case with Twilio before sending SMS at any real volume, or messages get filtered/blocked. Do this early — it can take days.
- **Consent**: only text people who've called you or opted in somewhere (a form, a booking). Don't buy lists and blast them.
- **STOP handling**: always honor STOP/unsubscribe (this starter does it in code; Twilio also enforces it at the carrier level as a backstop).
- **Recording disclosure**: if you ever add call recording or transcription of the *voice* call itself (not just the SMS), most US states require notifying the caller.

## Where this earns its keep vs. where it doesn't

**Strong fit**: home services, salons/spas, dental/med spas, contractors, real estate showings — high call volume, simple booking logic, customers expect a fast text back anyway.

**Weak fit as a full replacement**: anything with complex triage (urgent medical), heavy negotiation (B2B sales with custom pricing), or where the brand voice genuinely requires a specific human. Use it as a **filter and first-responder** in those cases — it handles the 80% of routine "are you open / can I book / how much roughly" traffic and hands off the rest, rather than trying to replace judgment calls.

## Rollout plan if you're building this for clients (not just yourself)

1. Pick one pilot business, get their real Twilio number ported/registered, and run it for 2 weeks with the owner still getting every transcript.
2. Tune `AI_PERSONA` and the system prompt in `src/lib/ai.js` based on real conversations — this is where most of the "it doesn't sound right" complaints get fixed.
3. Only then start on old-lead revival (workflow 2) — it depends on having a real lead list, which most small businesses don't have cleanly organized until you've been working with them a bit.
4. Price it as a monthly service (most agencies doing this charge $200–$600/mo per location) rather than a one-time build — the ongoing tuning and the phone number itself are recurring costs and recurring value.
